/// <reference path="qunit/qunit.js" />
/// <reference path="../jsrender.js" />
/// <reference path="../jquery.observable.js" />
/// <reference path="../jquery.views.js" />
