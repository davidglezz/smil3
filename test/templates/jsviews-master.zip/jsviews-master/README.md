## JsViews: Next-generation jQuery Templates
_Interactive data-driven views, built on top of [JsRender templates](https://github.com/BorisMoore/jsrender)_<br/>
To view demo pages (on gh-branch) navigate to [http://borismoore.github.com/jsviews/demos/index.html](http://borismoore.github.com/jsviews/demos/index.html "JsViews Samples").<br/>
See also [JsRender step-by-step samples](http://borismoore.github.com/jsrender/demos/index.html).<br/>

See [Approaching Beta: What's changing in JsRender and JsViews](http://www.borismoore.com/2012/03/approaching-beta-whats-changing-in_06.html) for documentation of changes.<br/>

**Status:** This version of JsViews is a beta candidate. APIs and code are now stable.
