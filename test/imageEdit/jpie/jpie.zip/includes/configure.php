<?php
	define('ROOT_PATH',$_SERVER['DOCUMENT_ROOT'].'/');
	define('IMAGE_PATH', ROOT_PATH . 'jpie/images/');
	define('TMP_IMAGE_PATH',ROOT_PATH . 'jpie/tmpImages/');
?>