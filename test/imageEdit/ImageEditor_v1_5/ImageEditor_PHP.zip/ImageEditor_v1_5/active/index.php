<? header("HTTP/1.0 403 Forbidden"); ?>
<html><head><title>Listing of the folder contents is prohibited</title></head><body></body></html>