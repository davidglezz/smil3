ImageEditor 1.5

You are free to use this code however you wish, but please leave the copyright, credits and license information in the source code as-is.

To get started, drop the ImageEditor directory on you PHP/GD-enabled server and call one of the following:
index.php?imageName=frog.jpg
index.php?imageName=frog.gif
index.php?imageName=frog.png

If you find this code particularly useful, feel free to support my hosting costs via PayPal (mail@peterfrueh.com).