   /==============\
  |  DB.CLASS.PHP  |
   \==============/

* Copy the db.class.php on your site to use it
* A list of all methods is available in html_docs/classDB.html
* The db.help.txt provides a quick overview of the functions you should use most and how to quickly execute and process queries
* See http://slaout.linux62.org/php/ for more help
