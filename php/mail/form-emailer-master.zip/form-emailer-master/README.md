#PHP Form Emailer

## About
This is one of my oldest scripts, but is still extremely practical & may be of use to someone. The idea is very simple: to email the contents of any web form to a person or persons. All you need to do is upload the script to your website, make a few tweaks to your web form and the script and you're all set.

## Demo
Check out my site for documentation:
http://www.benjaminkeen.com/open-source-projects/smaller-projects/old-stuff/form-emailer/

## Changelog

_1.2_ - Aug 29, 2007

Ben Keen
[@vancouverben](https://twitter.com/#!/vancouverben)